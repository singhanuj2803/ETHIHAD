# Databricks notebook source
!pip install openpyxl

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import col

# COMMAND ----------

# main path
source_path = "/dbfs/mnt/stppeedp/ppeedp/landing/data0/staging/eag/ey/cash_flow_analytics/"

# Define the path to write the output 
destination_path_chart_of_accounts = 'dbfs:/mnt/stppeedp/ppeedp/prod/eag/ey/fdw/mfr/chart_of_accounts_20241127'
destination_path_vendor_category = 'dbfs:/mnt/stppeedp/ppeedp/prod/eag/ey/fdw/mfr/vendor_category_20241127'

chart_of_accounts_path = source_path+'input_files/Chart of Accounts.xlsx'
vendor_category_path = source_path+'input_files/Vendor Category.xlsx'

# COMMAND ----------

# Process Chart of Accounts

# Read excel file
pd_df = pd.read_excel(chart_of_accounts_path,dtype=str)

# Create DataFrame using pandas df
df = spark.createDataFrame(pd_df).select([col(c).cast("string") for c in pd_df.columns])

# Write the result to destination in parquet
df.write.mode("overwrite").parquet(destination_path_chart_of_accounts)
print(f"Data has been successfully processed and written at {destination_path_chart_of_accounts}")

# COMMAND ----------

# Process Vendor Category

# Read excel file
pd_df = pd.read_excel(vendor_category_path,dtype=str)

# Create DataFrame using pandas df
df = spark.createDataFrame(pd_df)

# Write the result to destination in parquet
df.write.mode("overwrite").parquet(destination_path_vendor_category)
print(f"Data has been successfully processed and written at {destination_path_vendor_category}")

# COMMAND ----------

