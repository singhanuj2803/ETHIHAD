# Databricks notebook source
!pip install openpyxl

# COMMAND ----------

import pandas as pd
import glob
import re
from pyspark.sql.functions import col, datediff, when, lit, udf,to_date, date_add, date_sub, concat, coalesce, length
from pyspark.sql.types import IntegerType
from datetime import timedelta, datetime

# COMMAND ----------

def extract_date_from_filename(filename):
    """Extract date from filename in format 'dd.mm.yyyy'."""
    match = re.search(r'(\d{2})\.(\d{2})\.(\d{4})\.xlsx', filename)
    if match:
        day, month, year = match.groups()
        return f'{year}-{month}-{day}'  # Format as YYYY-MM-DD
    return None

def add_reporting_date(file_paths,sht_name):
    # Create an empty list to store DataFrames
    dfs = []
    for file in file_paths:
        # Extract the filename
        filename = file.split('/')[-1]
        
        # Read the Excel file
        df = pd.read_excel(file, sheet_name=sht_name, dtype=str)
        
        # Extract date from filename for all files
        reporting_date = extract_date_from_filename(filename)
        df['Reporting Date'] = reporting_date
        
        dfs.append(df)
    return dfs
    
# Define UDF to calculate working days
def network_days(start_date, end_date):
    if start_date is None or end_date is None:
        return None

    # Define weekend days (Saturday=5, Sunday=6)
    weekend = {5, 6}
    working_days_count = 0

    # Iterate through the date range
    current_date = start_date
    while current_date <= end_date:
        if current_date.weekday() not in weekend:
            working_days_count += 1
        current_date += timedelta(days=1)

    return working_days_count

# COMMAND ----------

# main path
source_path = "/dbfs/mnt/stppeedp/ppeedp/landing/data0/staging/eag/ey/ap_automation/"

# Define the path to write the output 
destination_path = 'dbfs:/mnt/stppeedp/ppeedp/prod/eag/ey/fdw/mfr/pmt_tat'
destination_path_sheet1 = 'dbfs:/mnt/stppeedp/ppeedp/prod/eag/ey/fdw/mfr/pmt_tat_sheet1'
pmt_tat_paths = source_path + 'pmt_tat/PMT*.xlsx'
supplier_mapping_path = source_path+'input_files/Supplier Mapping.xlsx'

# COMMAND ----------

# Reading Supplier Mapping 
supplier_mapping_df = pd.read_excel(supplier_mapping_path, dtype=str)
supplier_mapping = spark.createDataFrame(supplier_mapping_df)
supplier_mapping = supplier_mapping.withColumnRenamed("Vendor","SP Vendor").withColumnRenamed("Category","SP Category")

# COMMAND ----------

# Define the path to your Excel files
file_paths = glob.glob(pmt_tat_paths)

# Add Reporting Date Column
dfs = add_reporting_date(file_paths,sht_name='Final')

# Concatenate all DataFrames
combined_df = pd.concat(dfs, ignore_index=True)

# Rename columns to avoid errors during write
rename_dict = {
    "Payment block": "Payment_block",
    "Doc.status": "Doc status",
    "Ref.key (header) 2": "Ref key (header) 2",
    "Ref.key (header) 1": "Ref key (header) 1"
}

combined_df.rename(columns=rename_dict, inplace=True)

# Convert to Spark DataFrame and cast to StringType
pmt_tat_df = spark.createDataFrame(combined_df).select([col(c).cast("string") for c in combined_df.columns])

# Register UDF
network_days_udf = udf(network_days, IntegerType())

# Data transformation
pmt_tat_df = (pmt_tat_df
    .withColumn("PAT - Expected Clearing Date", 
        when(datediff(col("Net due date"), col("Posting Day")) < 7, date_add(to_date(col('Posting Day')), 3))
        .otherwise(date_sub(to_date(col("Net due date")), 7))
    )
    .withColumn("Expected Vs Actual", datediff(col("Clearing Entry Date"), col("PAT - Expected Clearing Date")))
    .withColumn("Expected Vs Actual - Excl Weekends", network_days_udf(col("PAT - Expected Clearing Date"), to_date(col("Clearing Entry Date"))))
    .withColumn("Exclusions", lit("NA"))
    .withColumn("Type", lit("NA"))
    .withColumn("Avg Pay terms", datediff(col("Net due date"), col("Document Date")))
    .withColumn("Pay Delay Grouping",
        when(col("Expected Vs Actual - Excl Weekends") <= 1, "1 day")
        .when((col("Expected Vs Actual - Excl Weekends") > 1) & (col("Expected Vs Actual - Excl Weekends") <= 3), "2 to 3 days")
        .when((col("Expected Vs Actual - Excl Weekends") > 3) & (col("Expected Vs Actual - Excl Weekends") <= 5), "4 to 5 days")
        .otherwise("Above 6 days")
    )
    .withColumn("Clearing Entry Date les Doc Date", network_days_udf(to_date(col("Document Date")), to_date(col("Clearing Entry Date"))))
    .withColumn("CC+Vendor", concat(col("Company Code"), col("Vendor"))).drop("AP Manager")
)
# Drop duplicates to keep only one row per CC_Code_Vendor
supplier_mapping_unique = supplier_mapping.dropDuplicates(["CC Code+Vendor"])

# Join with supplier_mapping_unique to get Vendor_Mapping
pmt_tat_df=pmt_tat_df.join(supplier_mapping_unique,pmt_tat_df["CC+Vendor"]==supplier_mapping_unique["CC Code+Vendor"], "left")\
    .drop(supplier_mapping_unique["Company Code"])\
    .drop("CC Code+Vendor","Team Lead","Vendor type","Vendor Status","CC+Vendor")\
    .withColumnRenamed("Manager","AP Manager")\
    .withColumn("AP Manager",coalesce(col("AP Manager"), lit('Unassigned')))

pmt_tat_df = pmt_tat_df.withColumn(
    "Category",
    when(
        (length(col("Vendor")) < 7) & (col("Vendor").rlike("^[0-9]+$")), "Staff Expense"  # Numeric and less than 7 digits
    ).when(
        (length(col("Vendor")) < 7) & (col("Vendor").rlike("^[a-zA-Z0-9]+$")), "ICH NON DOC/ICH DOC"  # Alphanumeric and less than 7 digits
    ).when(
        col("SP Vendor").isNotNull(), col("SP Category")  # Use the lookup value if available
    ).otherwise("Unassigned")  # Default to "Unassigned" if no other conditions are met
).withColumn("Category", coalesce(col("Category"), lit('Unassigned'))).drop("SP Vendor", "SP Category")

# Write the data to the destination
pmt_tat_df.write.mode("overwrite").parquet(destination_path)
print(f"Data has been successfully processed and written at {destination_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sheet1 Processing

# COMMAND ----------

# Define the path to your Excel files
file_paths = glob.glob(pmt_tat_paths)

# Add Reporting Date Column
dfs = add_reporting_date(file_paths,sht_name='Sheet1')

# Concatenate all DataFrames
combined_df = pd.concat(dfs, ignore_index=True)

# Rename columns to avoid errors during write
rename_dict = {
    "Payment block": "Payment_block",
    "Doc.status": "Doc status",
    "Ref.key (header) 2": "Ref key (header) 2",
    "Ref.key (header) 1": "Ref key (header) 1"
}

combined_df.rename(columns=rename_dict, inplace=True)

# Convert to Spark DataFrame and cast to StringType
pmt_tat_df = spark.createDataFrame(combined_df).select([col(c).cast("string") for c in combined_df.columns])


# Write the data to the destination
pmt_tat_df.write.mode("overwrite").parquet(destination_path_sheet1)
print(f"Data has been successfully processed and written at {destination_path_sheet1}")

# COMMAND ----------

